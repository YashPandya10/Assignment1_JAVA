package shapes;

/**
 * Cone shape. Inherits from shape.
 * Cone has height and radius 
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public class Cone extends Shape {

    // Fields
    private double radius;

    // Constructor
    public Cone(double height, double radius) {  //Parameters height and radius 
        super(height);
        this.radius = radius;
    }

    // Getter
    public double getRadius() {
        return radius;
    }

    // Abstract Methods
    @Override
    public double getBaseArea() {
        return Math.PI * Math.pow(radius, 2);
    }

    @Override
    public double getVolume() {
        return (height / 3.0) * Math.PI * Math.pow(radius, 2);
    }

    // To String
    @Override
    public String toString() {
        return String.format("Cone [height=%.3f, radius=%.3f, baseArea=%.3f, volume=%.3f]",
                height, radius, getBaseArea(), getVolume());
    }
}

