package shapes;

/**
 * Abstract class for shapes 
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public abstract class Shape implements Comparable<Shape> {
    
    // Fields
    protected double height;  // property for all shapes

    // Constructor
    public Shape(double height) { //Constructs a shape given the height. Parameter - height
        this.height = height;
    }

    // Getters
    //Returns the height of the shape.
    public double getHeight() {
        return height;
    }

    // Abstract Methods

   // Calcs and returns base area of shape. each shape has its own calculation
    public abstract double getBaseArea();

   // Calcs and returns base volume of shape. each shape has its own calculation
    public abstract double getVolume();

    /**
     * Natural ordering for Shape objects — compares by height.
     * Returns a positive number if this shape is taller,
     * a negative number if shorter, and zero if equal.
     */
    @Override
    public int compareTo(Shape other) {
        if (this.height > other.height) {
            return 1;
        } else if (this.height < other.height) {
            return -1;
        } else {
            return 0;
        }
    }

    // String To
    @Override
    public String toString() {
        return String.format("%s [height=%.3f, baseArea=%.3f, volume=%.3f]",
                this.getClass().getSimpleName(), getHeight(), getBaseArea(), getVolume());
    }
}

