package shapes;

/**
 * OctagonalPrism shape. Inherits from Shape.
 * OctagonalPrism has height and edge length.
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public class OctagonalPrism extends Shape {

    // Fields
    private double edgeLength;

    // Constructor
    public OctagonalPrism(double height, double edgeLength) { // Parameters height and edge length
        super(height);
        this.edgeLength = edgeLength;
    }

    // Getter
    public double getEdgeLength() {
        return edgeLength;
    }

    // Abstract Methods
    @Override
    public double getBaseArea() {
        return 2 * (1 + Math.sqrt(2)) * Math.pow(edgeLength, 2);
    }

    @Override
    public double getVolume() {
        return getBaseArea() * height;
    }

    // To String
    @Override
    public String toString() {
        return String.format("OctagonalPrism [height=%.3f, edgeLength=%.3f, baseArea=%.3f, volume=%.3f]",
                height, edgeLength, getBaseArea(), getVolume());
    }
}

