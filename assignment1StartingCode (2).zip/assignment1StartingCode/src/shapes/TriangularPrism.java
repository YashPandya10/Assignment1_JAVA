package shapes;

/**
 * TriangularPrism shape. Inherits from Shape.
 * TriangularPrism has height and edge length.
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public class TriangularPrism extends Shape {

    // Fields
    private double edgeLength;

    // Constructor
    public TriangularPrism(double height, double edgeLength) { // Parameters height and edge length
        super(height);
        this.edgeLength = edgeLength;
    }

    // Getter
    public double getEdgeLength() {
        return edgeLength;
    }

    // Abstract Methods
    @Override
    public double getBaseArea() {
        return (Math.sqrt(3) / 4) * Math.pow(edgeLength, 2);
    }

    @Override
    public double getVolume() {
        return getBaseArea() * height;
    }

    // To String
    @Override
    public String toString() {
        return String.format("TriangularPrism [height=%.3f, edgeLength=%.3f, baseArea=%.3f, volume=%.3f]",
                height, edgeLength, getBaseArea(), getVolume());
    }
}
