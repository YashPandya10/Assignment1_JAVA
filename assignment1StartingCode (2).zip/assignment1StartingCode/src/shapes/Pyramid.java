package shapes;

/**
 * Pyramid shape. Inherits from Shape.
 * Pyramid has height and edge length.
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public class Pyramid extends Shape {

    // Fields
    private double edgeLength;

    // Constructor
    public Pyramid(double height, double edgeLength) { // Parameters height and edge length
        super(height);
        this.edgeLength = edgeLength;
    }

    // Getter
    public double getEdgeLength() {
        return edgeLength;
    }

    // Abstract Methods
    @Override
    public double getBaseArea() {
        return Math.pow(edgeLength, 2);
    }

    @Override
    public double getVolume() {
        return (1.0 / 3.0) * Math.pow(edgeLength, 2) * height;
    }

    // To String
    @Override
    public String toString() {
        return String.format("Pyramid [height=%.3f, edgeLength=%.3f, baseArea=%.3f, volume=%.3f]",
                height, edgeLength, getBaseArea(), getVolume());
    }
}

