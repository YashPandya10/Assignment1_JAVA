package shapes;

/**
 * PentagonalPrism shape. Inherits from Shape.
 * PentagonalPrism has height and edge length.
 * 
 * Date: October 20, 2025
 * Author: Jack Gess
 * Course: CPRG 304 - Assignment 1
 */
public class PentagonalPrism extends Shape {

    // Fields
    private double edgeLength;

    // Constructor
    public PentagonalPrism(double height, double edgeLength) { // Parameters height and edge length
        super(height);
        this.edgeLength = edgeLength;
    }

    // Getter
    public double getEdgeLength() {
        return edgeLength;
    }

    // Abstract Methods
    @Override
    public double getBaseArea() {
        // 54 degrees converted to radians for Math.tan()
        return (5 * Math.pow(edgeLength, 2) * Math.tan(Math.toRadians(54))) / 4;
    }

    @Override
    public double getVolume() {
        return getBaseArea() * height;
    }

    // To String
    @Override
    public String toString() {
        return String.format("PentagonalPrism [height=%.3f, edgeLength=%.3f, baseArea=%.3f, volume=%.3f]",
                height, edgeLength, getBaseArea(), getVolume());
    }
}

