package appDomain;

import shapes.*;
import utilities.*;
import java.io.File;
import java.util.Comparator;
import java.util.Scanner;

/**
 * Assignment 1 - Complexity and Sorting
 * Main Controller
 *
 * Responsibilities:
 * 1. Parse command-line arguments (-f, -t, -s)
 * 2. Load shape data from file
 * 3. Select correct comparator (height, volume, base area)
 * 4. Call sorting algorithm
 * 5. Measure sorting time
 * 6. Display output (first, every 1000th, last)
 */
public class AppDriver {

    public static void main(String[] args) {
        String fileName = null;
        String compareType = null;
        String sortType = null;

        
        for (String arg : args) {
            arg = arg.toLowerCase();
            if (arg.startsWith("-f")) fileName = arg.substring(2);
            else if (arg.startsWith("-t")) compareType = arg.substring(2);
            else if (arg.startsWith("-s")) sortType = arg.substring(2);
        }

        
        if (fileName == null || compareType == null || sortType == null) {
            System.out.println("Usage: java -jar Sort.jar -f<file> -t<h|v|a> -s<b|i|s|m|q|z>");
            System.out.println("Example: java -jar Sort.jar -fres/shapes1.txt -tv -sq");
            return;
        }

        
        Shape[] shapes = readShapesFromFile(fileName);
        if (shapes.length == 0) {
            System.out.println("No valid shapes found in file.");
            return;
        }

        
        Comparator<Shape> comparator;
        switch (compareType) {
            case "h":
                // Use Comparable for height (but reverse for descending order)
                comparator = new Comparator<Shape>() {
                    @Override
                    public int compare(Shape s1, Shape s2) {
                        return s2.compareTo(s1);
                    }
                };
                break;
            case "v":
                // Compare by volume in descending order
                comparator = new Comparator<Shape>() {
                    @Override
                    public int compare(Shape s1, Shape s2) {
                        return Double.compare(s2.getVolume(), s1.getVolume());
                    }
                };
                break;
            case "a":
                // Compare by base area in descending order  
                comparator = new Comparator<Shape>() {
                    @Override
                    public int compare(Shape s1, Shape s2) {
                        return Double.compare(s2.getBaseArea(), s1.getBaseArea());
                    }
                };
                break;
            default:
                System.out.println("Invalid compare type! Use h (height), v (volume), or a (base area).");
                return;
        }

        
        long start = System.currentTimeMillis();
        switch (sortType) {
            case "b": BubbleSort.sort(shapes, comparator); break;
            case "i": InsertionSort.sort(shapes, comparator); break;
            case "s": SelectionSort.sort(shapes, comparator); break;
            case "m": MergeSort.sort(shapes, comparator); break;
            case "q": QuickSort.sort(shapes, comparator); break;
            case "z": CustomSort.sort(shapes, comparator); break;
            default:
                System.out.println("Invalid sort type! Use b, i, s, m, q, or z.");
                return;
        }
        long end = System.currentTimeMillis();

        String sortName = getSortName(sortType);
        System.out.println(sortName + " run time was: " + (end - start) + " milliseconds");
        
        displayResults(shapes, compareType);
    }
    private static String getSortName(String sortType) {
        switch (sortType) {
            case "b": return "Bubble Sort";
            case "i": return "Insertion Sort";
            case "s": return "Selection Sort";
            case "m": return "Merge Sort";
            case "q": return "Quick Sort";
            case "z": return "Custom Sort"; 
            default: return "Unknown Sort";
        }
    }

    
    private static Shape[] readShapesFromFile(String fileName) {
        try (Scanner sc = new Scanner(new File(fileName))) {
            int n = Integer.parseInt(sc.nextLine().trim());
            Shape[] shapes = new Shape[n];
            for (int i = 0; i < n; i++) {
                String[] tokens = sc.nextLine().trim().split(" ");
                shapes[i] = ShapeFactory.createShape(tokens);
            }
            return shapes;
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
            return new Shape[0];
        }
    }

   
    private static void displayResults(Shape[] shapes, String compareType) {
        if (shapes.length == 0) return;

     
        String propertyName;
        switch (compareType) {
            case "h": propertyName = "Height"; break;
            case "v": propertyName = "Volume"; break;
            case "a": propertyName = "Base Area"; break;
            default: propertyName = "Height";
        }

        System.out.println("First element is: " + shapes[0].getClass().getName() + 
                           "    " + propertyName + ": " + getPropertyValue(shapes[0], compareType));
        
      
        for (int i = 999; i < shapes.length; i += 1000) {
            System.out.println((i+1) + "-th element: " + shapes[i].getClass().getName() + 
                              "    " + propertyName + ": " + getPropertyValue(shapes[i], compareType));
        }
        
        System.out.println("Last element is: " + shapes[shapes.length-1].getClass().getName() + 
                           "    " + propertyName + ": " + getPropertyValue(shapes[shapes.length-1], compareType));
    }

    private static double getPropertyValue(Shape shape, String compareType) {
        switch (compareType) {
            case "h": return shape.getHeight();
            case "v": return shape.getVolume();
            case "a": return shape.getBaseArea();
            default: return shape.getHeight();
        }
    }

}


class ShapeFactory {
    public static Shape createShape(String[] tokens) {
        String type = tokens[0];
        double height = Double.parseDouble(tokens[1]);
        double val = Double.parseDouble(tokens[2]);

        switch (type.toLowerCase()) {
            case "cylinder": return new Cylinder(height, val);
            case "cone": return new Cone(height, val);
            case "pyramid": return new Pyramid(height, val);
            case "squareprism": return new SquarePrism(height, val);
            case "triangularprism": return new TriangularPrism(height, val);
            case "pentagonalprism": return new PentagonalPrism(height, val);
            case "octagonalprism": return new OctagonalPrism(height, val);
            default: throw new IllegalArgumentException("Unknown shape: " + type);
        }
    }
}

