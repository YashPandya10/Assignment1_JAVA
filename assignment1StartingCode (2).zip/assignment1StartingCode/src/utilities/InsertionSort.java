package utilities;

import java.util.Comparator;
import shapes.Shape;

public class InsertionSort {
    public static void sort(Shape[] arr, Comparator<Shape> cmp) {
        for (int i = 1; i < arr.length; i++) {
            Shape key = arr[i];
            int j = i - 1;
            while (j >= 0 && cmp.compare(arr[j], key) > 0) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
}
