package utilities;

import java.util.Comparator;
import shapes.Shape;

public class SelectionSort {
    public static void sort(Shape[] arr, Comparator<Shape> cmp) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (cmp.compare(arr[minIndex], arr[j]) > 0) {
                    minIndex = j;
                }
            }
            Shape temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}
