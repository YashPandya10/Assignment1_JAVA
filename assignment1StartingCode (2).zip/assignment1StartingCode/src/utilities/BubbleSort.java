package utilities;

import java.util.Comparator;
import shapes.Shape;

public class BubbleSort {
    public static void sort(Shape[] arr, Comparator<Shape> cmp) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (cmp.compare(arr[j], arr[j + 1]) > 0) {
                    Shape temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
