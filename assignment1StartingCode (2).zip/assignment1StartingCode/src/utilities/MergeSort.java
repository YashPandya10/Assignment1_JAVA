package utilities;

import java.util.Comparator;
import shapes.Shape;

public class MergeSort {
    public static void sort(Shape[] arr, Comparator<Shape> cmp) {
        mergeSort(arr, 0, arr.length - 1, cmp);
    }

    private static void mergeSort(Shape[] arr, int left, int right, Comparator<Shape> cmp) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(arr, left, mid, cmp);
            mergeSort(arr, mid + 1, right, cmp);
            merge(arr, left, mid, right, cmp);
        }
    }

    private static void merge(Shape[] arr, int left, int mid, int right, Comparator<Shape> cmp) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Shape[] L = new Shape[n1];
        Shape[] R = new Shape[n2];

        for (int i = 0; i < n1; ++i) L[i] = arr[left + i];
        for (int j = 0; j < n2; ++j) R[j] = arr[mid + 1 + j];

        int i = 0, j = 0;
        int k = left;
        while (i < n1 && j < n2) {
            if (cmp.compare(L[i], R[j]) <= 0) {
                arr[k++] = L[i++];
            } else {
                arr[k++] = R[j++];
            }
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }
}
